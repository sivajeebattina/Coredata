//
//  UpdateViewController.h
//  CoreDataAssignment
//
//  Created by pcs20 on 9/26/14.
//  Copyright (c) 2014 Paradigmcreatives. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UpdateViewController : UIViewController

-(void)updateMethodcalled;

@end
