//
//  Employee.m
//  CoreDataAssignment
//
//  Created by pcs20 on 9/25/14.
//  Copyright (c) 2014 Paradigmcreatives. All rights reserved.
//

#import "Employee.h"
#import "Transactions.h"


@implementation Employee

@dynamic empName;
@dynamic empID;
@dynamic employeeDetails;

@end
